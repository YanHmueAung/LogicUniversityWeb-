﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicUniversityWeb.DataBase
{
    public class DataLink
    {
        public static string connectionString = "Server=DESKTOP-CCUEBU9;" + "Database=ADTeam6;" + "Integrated Security=true";

    }
}
