# LogicUniversity
Developed by Team 6 from GDipSA49 AD team. 
In this app, we use machine learning to predit the order from other departments.
